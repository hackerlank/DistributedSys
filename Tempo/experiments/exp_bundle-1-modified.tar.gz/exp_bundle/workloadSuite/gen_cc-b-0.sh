#!/bin/bash

./WorkloadSynthesis.pl --inPath=./CC-b-clearnedSummary.tsv --outPrefix=CC-b --repeats=1 --samples=3 --length=3600 --traceStart=1312330422 --traceEnd=1311641416
