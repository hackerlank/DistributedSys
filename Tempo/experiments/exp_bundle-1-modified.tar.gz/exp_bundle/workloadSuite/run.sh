#!/bin/bash

sleep 15; # make sure fair allocation is effective

./gen_input.sh 2>&1 > gen_input.log

./gen_script.sh prod 300 1 241 2>&1 >  gen_script.log
./gen_script.sh engineer 3000 21 241 >> gen_script.log

mv script_prod script_engineer ../

cd ../script_prod
nohup ./run-jobs-all.sh &

cd ../script_engineer
nohup ./run-jobs-all.sh &
