#!/bin/bash

hadoop jar HDFSWrite.jar org.apache.hadoop.examples.HDFSWrite -D mapred.job.queue.name=prod -conf ../conf/randomwriter_conf.xsl workGenInput
