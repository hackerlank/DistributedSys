#!/bin/bash

cp -R . /home/hadoop/
cd /home/hadoop/workloadSuite/

sh -x run.sh 2>&1 > run.log
