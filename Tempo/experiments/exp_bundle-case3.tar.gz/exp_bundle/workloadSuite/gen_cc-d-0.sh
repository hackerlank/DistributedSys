#!/bin/bash

./WorkloadSynthesis.pl --inPath=./CC-d-clearnedSummary.tsv --outPrefix=CC-d --repeats=1 --samples=30 --length=3600 --traceStart=1306436778 --traceEnd=1313432697
