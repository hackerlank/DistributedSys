#!/bin/bash

if [ $# -ne 4 ]; then
    echo "need 4 params"
    exit 1
fi

pool=$1
size1=$2
size2=$3
part=$4

java GenerateReplayScript $pool $size1 $size2 67108864 $part script_$pool workGenInput workGenOutput_$pool 67108864 /home/hadoop/swimOutput/$pool/ hadoop /home/hadoop/WorkGen.jar /home/hadoop/conf/workGenKeyValue_conf.xsl $pool
